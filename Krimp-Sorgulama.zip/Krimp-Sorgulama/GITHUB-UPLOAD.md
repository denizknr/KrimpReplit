# GitHub'a Krimp Sorgulama Projesini Yükleme

Replit'ten dosyalarınızı GitHub'a yüklemenin adım adım kılavuzu.

## ADIM 1: GitHub Hesabı Oluşturma

1. **GitHub Web Sitesine Gidin**: https://github.com
2. **Sağ üstte "Sign up" butonuna tıklayın**
3. Email adresinizi girin
4. Bir şifre oluşturun
5. Kullanıcı adı seçin (örn: `ktaendústri`, `krimp-app`, vb.)
6. Email doğrulaması yapın

> **Eğer zaten GitHub hesabınız varsa**, direkt **ADIM 2**'ye geçin.

---

## ADIM 2: Yeni Depo (Repository) Oluşturma

1. **GitHub'a Giriş Yapın**: https://github.com/login
2. **Sol tarafta "+" simgesine tıklayın** → **"New repository" seçin**
3. **Aşağıdaki bilgileri girin:**

   | Alan | Değer |
   |------|-------|
   | Repository name | `krimp-yuksekligi-sorgulama` |
   | Description | `Krimp Yüksekliği Sorgulama Sistemi - KTA Endüstri` |
   | Visibility | **Public** (herkese açık) veya **Private** (sadece siz) |
   | Add .gitignore | Python (yok seç, bizde zaten var) |
   | Add a license | MIT (yok seç, bizde zaten var) |

4. **"Create repository" butonuna tıklayın**

---

## ADIM 3: Replit'ten Dosyaları İndirme

### Seçenek A: Replit İnterfaceinden İndir (En Kolay)

1. **Replit sol panelinde "Files" sekmesi açık olduğundan emin olun**
2. **Proje klasörünün (kök dizin) üzerine sağ tıklayın**
3. **"Download" seçeneğini tıklayın**
4. Tarayıcınız dosyaları `.zip` olarak indirecektir
5. **Bilgisayarınızda bir klasöre çıkartın** (örn: `C:\Users\SizinAdınız\krimp-sorgulama`)

### Seçenek B: Komut Satırı ile İndir (Git Kullanarak)

Bilgisayarınızda terminal/komut satırı açın:

```bash
# Replit projenizin klonunu alın
# (Replit hesabınız ve proje linkine ihtiyacınız var)
git clone https://replit.com/@yourusername/krimp-yuksekligi-sorgulama.git krimp-sorgulama
cd krimp-sorgulama
```

---

## ADIM 4: Git Yapılandırması (Bilgisayarınızda)

1. **Git'i İndir ve Kur** (Eğer yoksa): https://git-scm.com/download
2. **Terminal/Komut Satırını Açın** ve aşağıdaki komutları çalıştırın:

```bash
# Git'in kişisel bilgilerinizi tanıması için:
git config --global user.name "Adınız Soyadınız"
git config --global user.email "email@example.com"
```

**Örnek:**
```bash
git config --global user.name "Ahmet Yılmaz"
git config --global user.email "ahmet@ktaendústri.com"
```

---

## ADIM 5: GitHub'a İlk Push (Yükleme)

Terminal/Komut Satırında, indirdiğiniz proje klasöründe çalışın:

```bash
# 1. Proje klasörüne gidin
cd C:\Users\SizinAdınız\krimp-sorgulama
# veya
cd /Users/SizinAdınız/krimp-sorgulama
# veya
cd /home/SizinAdınız/krimp-sorgulama
```

```bash
# 2. Git deposunu başlatın
git init

# 3. Tüm dosyaları ekleyin
git add .

# 4. İlk commit'i oluşturun
git commit -m "Initial commit: Krimp Yüksekliği Sorgulama Uygulaması"

# 5. Main branch'ine geçin
git branch -M main

# 6. GitHub deposunu uzak depo olarak ekleyin
# (YOURUSERNAME yerine kendi GitHub kullanıcı adınızı yazın!)
git remote add origin https://github.com/YOURUSERNAME/krimp-yuksekligi-sorgulama.git

# 7. GitHub'a yükleyin
git push -u origin main
```

**Örnek:**
```bash
git remote add origin https://github.com/ktaendústri/krimp-yuksekligi-sorgulama.git
git push -u origin main
```

### GitHub Token ile Giriş

İlk push sırasında GitHub kimlik doğrulaması isterse:

**Windows/Mac/Linux (Modern Git):**
- GitHub hesabınız ve şifreniz istenir
- Veya browser açılır ve kimlik doğrulaması yaparsınız

---

## ADIM 6: Kontrol Etme

1. **GitHub'u Açın**: https://github.com/YOURUSERNAME/krimp-yuksekligi-sorgulama
2. **Dosyalarınızın yüklendiğini görün:**
   - ✅ `client/` klasörü
   - ✅ `server/` klasörü
   - ✅ `shared/` klasörü
   - ✅ `script/` klasörü
   - ✅ `README.md`
   - ✅ `CONTRIBUTING.md`
   - ✅ `.env.example`
   - ✅ `LICENSE`
   - ✅ `package.json`

---

## ADIM 7: Dosya Güncellemeleri (İleride)

Projeyi geliştirmeye devam ettikçe, yeni değişiklikleri GitHub'a yüklemek için:

```bash
# Değişiklik yapın (dosyaları edit edin, vb.)

# Değişiklikleri stage edin
git add .

# Commit oluşturun
git commit -m "Açıklayıcı mesaj yazın"

# GitHub'a yükleyin
git push
```

**Commit Mesajı Örnekleri:**
```bash
git commit -m "Mobil UI'yi optimize et"
git commit -m "Yeni API endpoint'i ekle"
git commit -m "Hataları düzelt"
git commit -m "Veritabanı şeması güncelle"
```

---

## Hata Giderme

### Hata: "fatal: not a git repository"

**Çözüm**: Proje klasörünün içinde olduğunuzdan emin olun.

```bash
cd C:\Users\SizinAdınız\krimp-sorgulama
pwd  # veya cd (dizin kontrol etmek için)
git status  # Git depo kontrolü
```

### Hata: "Permission denied" veya kimlik doğrulaması başarısız

**Çözüm 1 - SSH Anahtarı Kullan:**
```bash
# SSH anahtarı oluşturun (bilgisayarda ilk kez)
ssh-keygen -t ed25519 -C "email@example.com"
# Boş bırakıp Enter'a basın (varsayılan lokasyon için)

# GitHub'a SSH anahtarı ekleyin:
# 1. https://github.com/settings/keys
# 2. "New SSH key" tıklayın
# 3. Public anahtarı (id_ed25519.pub) GitHub'a yapıştırın
```

**Çözüm 2 - GitHub Token Kullan:**
```bash
# https://github.com/settings/tokens
# 1. "Generate new token (classic)" tıklayın
# 2. "repo" iznini seçin
# 3. Token'ı kopyalayın

# Push yaparken token'ı şifre olarak kullanın
git push -u origin main
# Kullanıcı adı: YOURUSERNAME
# Şifre: Token'ı yapıştırın
```

### Hata: "branch 'main' set up to track 'origin/main' but the upstream is gone"

**Çözüm:**
```bash
git branch --unset-upstream
git push -u origin main
```

---

## Özet Komutlar (Hızlı Referans)

```bash
# İlk yükleme
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOURUSERNAME/krimp-yuksekligi-sorgulama.git
git push -u origin main

# Güncellemeleri yükleme
git add .
git commit -m "Açıklama yazın"
git push
```

---

## Başarı!

Tebrikler! Projeniz GitHub'da yayında. Şimdi:

- ✅ Link'i paylaşabilirsiniz: `https://github.com/YOURUSERNAME/krimp-yuksekligi-sorgulama`
- ✅ Başkalarının clone'laması için: `git clone https://github.com/YOURUSERNAME/krimp-yuksekligi-sorgulama.git`
- ✅ İş arkadaşlarınız katkı verebilir (Pull Request ile)

---

## Ek Kaynaklar

- **Git Kılavuzu**: https://git-scm.com/doc
- **GitHub Yardım**: https://docs.github.com
- **GitHub Masaüstü (GUI)**: https://desktop.github.com (komut satırı olmadan)

---

**Herhangi bir sorunuz varsa, GitHub Issues sekmesini açıp soru sorabilirsiniz.**

İyi geliştirmeyi dileriz! 🚀
