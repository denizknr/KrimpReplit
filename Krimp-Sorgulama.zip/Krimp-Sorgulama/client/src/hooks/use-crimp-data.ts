import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { CrimpData } from "@shared/schema";

export function useKontaklar() {
  return useQuery<string[]>({
    queryKey: [api.crimpData.uniqueKontak.path],
    queryFn: async () => {
      const res = await fetch(api.crimpData.uniqueKontak.path, { credentials: "include" });
      if (!res.ok) throw new Error("Kontak numaraları yüklenemedi");
      return res.json();
    },
  });
}

export function useKesitler(kontakNo?: string) {
  return useQuery<string[]>({
    queryKey: [api.crimpData.uniqueKesit.path, kontakNo],
    queryFn: async () => {
      if (!kontakNo) return [];
      const params = new URLSearchParams({ kontakNo });
      const res = await fetch(`${api.crimpData.uniqueKesit.path}?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Kesitler yüklenemedi");
      return res.json();
    },
    enabled: !!kontakNo,
  });
}

export function useCrimpData(kontakNo?: string, kesit?: string) {
  return useQuery<CrimpData[]>({
    queryKey: [api.crimpData.list.path, kontakNo, kesit],
    queryFn: async () => {
      if (!kontakNo || !kesit) return [];
      const params = new URLSearchParams({ kontakNo, kesit });
      const res = await fetch(`${api.crimpData.list.path}?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error("Veriler yüklenemedi");
      return res.json();
    },
    enabled: !!kontakNo && !!kesit,
  });
}
