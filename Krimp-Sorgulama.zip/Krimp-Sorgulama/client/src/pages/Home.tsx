import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Box, Ruler, Wrench, Activity, AlertCircle, RefreshCw, ChevronRight } from "lucide-react";
import { SearchableSelect } from "@/components/SearchableSelect";
import { useKontaklar, useKesitler, useCrimpData } from "@/hooks/use-crimp-data";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [kontakNo, setKontakNo] = useState("");
  const [kesit, setKesit] = useState("");

  const { data: kontaklar = [], isLoading: isKontaklarLoading } = useKontaklar();
  const { data: kesitler = [], isLoading: isKesitlerLoading } = useKesitler(kontakNo);
  const { data: crimpData = [], isLoading: isCrimpLoading } = useCrimpData(kontakNo, kesit);

  const result = useMemo(() => (crimpData.length > 0 ? crimpData[0] : null), [crimpData]);

  const handleKontakChange = (val: string) => {
    setKontakNo(val);
    setKesit(""); // Reset kesit when kontak changes
  };

  const handleReset = () => {
    setKontakNo("");
    setKesit("");
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Abstract Background Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-[#f0a500]/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-[#4a9eff]/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="w-full max-w-4xl z-10 space-y-8">
        
        {/* Header Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center space-y-2 md:space-y-4"
        >
          <div className="inline-flex items-center justify-center p-2 md:p-3 mb-1 rounded-2xl bg-white/5 border border-white/10 shadow-xl backdrop-blur-sm">
            <Ruler className="w-6 h-6 md:w-8 h-8 text-[#f0a500]" />
          </div>
          <h1 className="text-2xl md:text-5xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white to-white/70">
            Krimp Sorgulama
          </h1>
          <p className="text-muted-foreground text-sm md:text-xl max-w-2xl mx-auto px-4">
            Hassas parametreleri anında görüntüleyin.
          </p>
        </motion.div>

        {/* Search Form Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1, ease: "easeOut" }}
          className="glass-card rounded-2xl md:rounded-3xl p-4 sm:p-6 md:p-8 shadow-2xl mx-auto w-full"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <div className="space-y-2 md:space-y-3">
              <label className="text-[10px] md:text-sm font-semibold tracking-wide text-muted-foreground uppercase flex items-center gap-2">
                <Box className="w-3 h-3 md:w-4 h-4" />
                Kontak Numarası
              </label>
              <SearchableSelect 
                options={kontaklar}
                value={kontakNo}
                onChange={handleKontakChange}
                placeholder="Kontak Seçiniz"
                searchPlaceholder="Kontak numarası ara..."
                isLoading={isKontaklarLoading}
              />
            </div>
            
            <div className="space-y-2 md:space-y-3">
              <label className="text-[10px] md:text-sm font-semibold tracking-wide text-muted-foreground uppercase flex items-center gap-2">
                <Activity className="w-3 h-3 md:w-4 h-4" />
                Kablo Kesiti (mm²)
              </label>
              <SearchableSelect 
                options={kesitler}
                value={kesit}
                onChange={setKesit}
                placeholder="Kesit Seçiniz"
                searchPlaceholder="Kesit ara..."
                disabled={!kontakNo}
                isLoading={isKesitlerLoading}
              />
            </div>
          </div>

          <div className="mt-6 md:mt-8 flex justify-end">
            <Button 
              variant="outline" 
              onClick={handleReset}
              disabled={!kontakNo && !kesit}
              className="h-10 md:h-12 px-4 md:px-6 rounded-xl border-white/10 hover:bg-white/5 hover:text-white transition-all text-sm md:text-base font-medium w-full md:w-auto"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Temizle
            </Button>
          </div>
        </motion.div>

        {/* Loading State */}
        {isCrimpLoading && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-8 md:py-12"
          >
            <div className="w-10 h-10 md:w-12 md:h-12 border-4 border-[#f0a500]/30 border-t-[#f0a500] rounded-full animate-spin" />
            <p className="mt-4 text-sm md:text-muted-foreground font-medium">Veriler getiriliyor...</p>
          </motion.div>
        )}

        {/* Results Area */}
        <AnimatePresence mode="wait">
          {result && !isCrimpLoading && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 30, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.98 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="space-y-3 md:space-y-6"
            >
              {/* Main Parameter Highlights */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2.5 md:gap-4">
                
                {/* Kalıp No */}
                <DataCard 
                  title="Kalıp No" 
                  value={result.kalipNo} 
                  icon={Wrench} 
                  colorHex="#4a9eff" // Blue
                  delay={0.1}
                />
                
                {/* Krimp Yüksekliği */}
                <DataCard 
                  title="Krimp Yüks." 
                  value={result.krimpYuksekligi} 
                  unit="mm"
                  icon={Ruler} 
                  colorHex="#f0a500" // Orange
                  delay={0.2}
                />

                {/* Çekme Kuvveti */}
                <DataCard 
                  title="Çekme Kuvv." 
                  value={result.cekmeKuvveti} 
                  unit="N"
                  icon={Activity} 
                  colorHex="#22c55e" // Green
                  delay={0.3}
                />

                {/* İzokrimp Yüksekliği */}
                <DataCard 
                  title="İzo. Yüks." 
                  value={result.izokrimpYuksekligi || "-"} 
                  unit={result.izokrimpYuksekligi && result.izokrimpYuksekligi !== "-" ? "mm" : ""}
                  icon={Box} 
                  colorHex="#bc8cff" // Purple
                  delay={0.4}
                />

                {/* Krimp Genişliği */}
                <DataCard 
                  title="Krimp Gen." 
                  value={result.krimpGenisligi || "-"} 
                  unit={result.krimpGenisligi && result.krimpGenisligi !== "-" ? "mm" : ""}
                  icon={Ruler} 
                  colorHex="#ec4899" // Pink/Purple accent
                  delay={0.5}
                />
              </div>

              {/* Auxiliary Info & Tolerance */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                className="flex flex-col md:flex-row items-center justify-between gap-3 p-3.5 md:p-6 rounded-2xl bg-white/[0.02] border border-white/5"
              >
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 md:gap-6 w-full md:w-auto">
                  <div className="flex items-center gap-1.5 text-[10px] md:text-sm text-muted-foreground">
                    <span className="font-semibold text-white">Kontak:</span> {result.kontakNo}
                  </div>
                  <ChevronRight className="hidden md:block w-4 h-4 text-white/20" />
                  <div className="flex items-center gap-1.5 text-[10px] md:text-sm text-muted-foreground">
                    <span className="font-semibold text-white">Kesit:</span> {result.kesit}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 px-2.5 py-1 md:px-4 md:py-2 rounded-full bg-[#f0a500]/10 border border-[#f0a500]/20 text-[#f0a500] text-[9px] md:text-sm font-semibold whitespace-nowrap">
                  <AlertCircle className="w-3 h-3 md:w-4 h-4" />
                  Tolerans: ± 0,05 mm
                </div>
              </motion.div>

            </motion.div>
          )}
        </AnimatePresence>

        {/* Empty State (When both are selected but no results) */}
        {kontakNo && kesit && !isCrimpLoading && !result && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-16 px-4 text-center glass-card rounded-3xl"
          >
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
              <AlertCircle className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Kayıt Bulunamadı</h3>
            <p className="text-muted-foreground max-w-md">
              Seçilen kontak numarası ve kesit değerine ait krimp verisi sistemde mevcut değil.
            </p>
          </motion.div>
        )}

      </div>
    </div>
  );
}

// Reusable animated DataCard component
function DataCard({ 
  title, 
  value, 
  unit, 
  icon: Icon, 
  colorHex, 
  delay 
}: { 
  title: string; 
  value: string; 
  unit?: string;
  icon: React.ElementType; 
  colorHex: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: "easeOut" }}
      className="relative overflow-hidden group rounded-2xl md:rounded-3xl glass-card p-3 md:p-6 flex flex-col justify-between min-h-[100px] md:min-h-[140px] hover-elevate cursor-default border border-white/5"
      style={{ 
        '--hover-bg': `${colorHex}08`, 
        '--hover-border': `${colorHex}30` 
      } as React.CSSProperties}
    >
      <div 
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
        style={{ backgroundColor: 'var(--hover-bg)' }}
      />
      <div 
        className="absolute inset-0 border border-transparent group-hover:border-[color:var(--hover-border)] rounded-2xl md:rounded-3xl transition-colors duration-500 pointer-events-none"
      />
      
      <div className="relative z-10 flex items-center gap-1.5 md:gap-3 mb-1.5 md:mb-4">
        <div 
          className="p-1 md:p-2 rounded-lg md:rounded-xl bg-white/5 backdrop-blur-sm"
          style={{ color: colorHex }}
        >
          <Icon className="w-3.5 h-3.5 md:w-5 h-5" />
        </div>
        <h3 className="text-[9px] md:text-sm font-semibold tracking-wide text-muted-foreground uppercase truncate">
          {title}
        </h3>
      </div>
      
      <div className="relative z-10 flex items-baseline gap-0.5 mt-auto">
        <span 
          className="text-lg md:text-2xl lg:text-3xl font-bold tracking-tight break-words"
          style={{ color: colorHex }}
        >
          {value}
        </span>
        {unit && (
          <span className="text-muted-foreground font-medium text-[10px] md:text-sm lg:text-lg ml-0.5 shrink-0">
            {unit}
          </span>
        )}
      </div>
    </motion.div>
  );
}
