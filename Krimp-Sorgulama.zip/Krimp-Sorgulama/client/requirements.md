## Packages
framer-motion | Smooth animations and stunning UI reveals for the result cards
clsx | Standard utility for class merging
tailwind-merge | Standard utility for class merging
@tanstack/react-query | Standard data fetching
lucide-react | Standard icons

## Notes
The application is styled natively in a premium dark mode using #1a1a1a as background and #242424 for cards.
Custom accent colors are implemented inline using Tailwind arbitrary values to guarantee exact matches without tailwind.config.ts changes.
Combobox implementation relies on existing Shadcn Command and Popover primitives.
