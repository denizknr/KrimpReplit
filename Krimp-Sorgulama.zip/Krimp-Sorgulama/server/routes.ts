import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.crimpData.list.path, async (req, res) => {
    try {
      const { kontakNo, kesit } = req.query;
      const data = await storage.getCrimpData(kontakNo as string, kesit as string);
      res.json(data);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.crimpData.uniqueKontak.path, async (req, res) => {
    try {
      const kontaklar = await storage.getUniqueKontaklar();
      res.json(kontaklar);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.crimpData.uniqueKesit.path, async (req, res) => {
    try {
      const { kontakNo } = req.query;
      const kesitler = await storage.getUniqueKesitler(kontakNo as string);
      res.json(kesitler);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Seed endpoint (internal use)
  app.post("/api/seed", async (req, res) => {
    try {
      const data = req.body;
      if (!Array.isArray(data)) {
        return res.status(400).json({ message: "Expected array of data" });
      }
      
      await storage.clearCrimpData();
      let count = 0;
      for (const item of data) {
        await storage.createCrimpData({
          kontakNo: item.kontakNo,
          kesit: item.kesit,
          kalipNo: item.kalipNo || "-",
          krimpYuksekligi: item.krimpYuksekligi || "-",
          krimpGenisligi: item.krimpGenisligi || "-",
          izokrimpYuksekligi: item.izokrimpYuksekligi || "-",
          cekmeKuvveti: item.cekmeKuvveti || "-"
        });
        count++;
      }
      
      res.json({ message: `Seeded ${count} records successfully` });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: "Failed to seed data", error: String(err) });
    }
  });

  return httpServer;
}
