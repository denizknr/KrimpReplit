import { db } from "./db";
import { crimpData, type InsertCrimpData, type CrimpData } from "@shared/schema";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getCrimpData(kontakNo?: string, kesit?: string): Promise<CrimpData[]>;
  getUniqueKontaklar(): Promise<string[]>;
  getUniqueKesitler(kontakNo?: string): Promise<string[]>;
  createCrimpData(data: InsertCrimpData): Promise<CrimpData>;
  clearCrimpData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getCrimpData(kontakNo?: string, kesit?: string): Promise<CrimpData[]> {
    let query = db.select().from(crimpData);
    
    if (kontakNo && kesit) {
      return await query.where(and(eq(crimpData.kontakNo, kontakNo), eq(crimpData.kesit, kesit)));
    } else if (kontakNo) {
      return await query.where(eq(crimpData.kontakNo, kontakNo));
    } else if (kesit) {
      return await query.where(eq(crimpData.kesit, kesit));
    }
    
    return await query;
  }

  async getUniqueKontaklar(): Promise<string[]> {
    const results = await db.selectDistinct({ kontakNo: crimpData.kontakNo }).from(crimpData);
    return results.map(r => r.kontakNo).sort();
  }

  async getUniqueKesitler(kontakNo?: string): Promise<string[]> {
    let query = db.selectDistinct({ kesit: crimpData.kesit }).from(crimpData);
    
    if (kontakNo) {
      query = query.where(eq(crimpData.kontakNo, kontakNo)) as any;
    }
    
    const results = await query;
    return results.map(r => r.kesit).sort();
  }

  async createCrimpData(data: InsertCrimpData): Promise<CrimpData> {
    const [result] = await db.insert(crimpData).values(data).returning();
    return result;
  }

  async clearCrimpData(): Promise<void> {
    await db.delete(crimpData);
  }
}

export const storage = new DatabaseStorage();
