# Krimp Yüksekliği Sorgulama Sistemi

Crimp Height Query System - KTA Endüstri için geliştirilmiş web tabanlı krimp parametreleri sorgulama uygulaması.

## Özellikleri

- 🔍 **Hızlı Arama**: Kontak No ve Kesit (tel kesiti) bilgilerine göre krimp verilerini hızlıca bulma
- 📱 **Mobil Uyumlu**: Tablet ve akıllı telefonlarda (6.1" ekranlar) optimize edilmiş arayüz
- 🌙 **Koyu Tema**: Fabrika ortamında gözleri yorulmayan koyu tema tasarımı
- 🎨 **Renkli Göstergeler**: Farklı parametreler için renk kodlu kartlar
- 📊 **Detaylı Bilgiler**: Krimp yüksekliği, çekme kuvveti, izokrimp yüksekliği, krimp genişliği ve kalıp numarası

## Parametreler

Uygulama aşağıdaki krimp parametrelerini gösterir:

- **Kalıp No**: Üretim kalıbının numarası
- **Krimp Yüksekliği**: Sıkıştırma yüksekliği (mm)
- **Çekme Kuvveti**: İstenen çekme kuvveti (N)
- **İzokrimp Yüksekliği**: İzoklinik sıkıştırma yüksekliği (mm)
- **Krimp Genişliği**: Sıkıştırma genişliği (mm)

## Teknoloji

- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Express.js
- **Database**: PostgreSQL + Drizzle ORM
- **Styling**: Tailwind CSS
- **UI Components**: Shadcn/ui
- **State Management**: TanStack Query (React Query)
- **Routing**: Wouter

## Kurulum

### Gereksinimler

- Node.js 16+
- PostgreSQL

### Adımlar

1. Depoyu klonlayın:
```bash
git clone https://github.com/yourusername/krimp-yuksekligi-sorgulama.git
cd krimp-yuksekligi-sorgulama
```

2. Bağımlılıkları yükleyin:
```bash
npm install
```

3. Ortam değişkenlerini ayarlayın:
```bash
cp .env.example .env
```

`.env` dosyasını kendi PostgreSQL veritabanı bilgilerinizle düzenleyin.

4. Veritabanını başlatın:
```bash
npm run db:push
```

5. Uygulamayı çalıştırın:
```bash
npm run dev
```

Uygulama `http://localhost:5173` adresinde çalışacaktır.

## Veri Kaynağı

Krimp verileri `attached_assets/krimp_lookup_1772797939166.html` dosyasından otomatik olarak çıkarılır ve veritabanına yüklenir. Dosya 1548 krimp kaydı içermektedir.

### Verileri Yeniden Yüklemek

```bash
npm run db:push  # Veritabanı şemasını senkronize et
```

Veritabanı şemasındaki değişiklikler için `drizzle.config.ts` ve `shared/schema.ts` dosyalarını kontrol edin.

## Proje Yapısı

```
├── client/              # React frontend
│   ├── src/
│   │   ├── pages/       # Sayfa bileşenleri
│   │   ├── components/  # UI bileşenleri
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Yardımcı fonksiyonlar
│   └── index.css        # Global stiller
├── server/              # Express backend
│   ├── routes.ts        # API yolları
│   ├── storage.ts       # Veri katmanı
│   └── index.ts         # Sunucu giriş noktası
├── shared/              # Frontend ve backend tarafından paylaşılan
│   ├── schema.ts        # Veritabanı ve Zod şemaları
│   └── routes.ts        # API yol tanımları
├── script/              # Yardımcı betikler
│   ├── extract_data.js  # HTML dosyasından veri çıkarma
│   └── seed.ts          # Veritabanı tohumlama
└── package.json         # Proje bağımlılıkları
```

## Kullanım

1. Uygulamayı açın
2. "Kontak No" alanına arama yapın veya listeden seçin
3. "Kesit (Tel Kesiti)" açılır menüsünden kesiti seçin
4. Krimp parametreleri otomatik olarak gösterilecektir

## Geliştirme

### Build

```bash
npm run build       # Üretim derlemesi
npm start          # Derlenmiş uygulamayı çalıştır
```

### Tür Kontrolü

```bash
npm run check      # TypeScript tür kontrolü
```

## Lisans

MIT

## İletişim

KTA Endüstri - [Web Sitesi](https://www.ktaendústri.com)

## Geliştirici Notları

- Veritabanı: PostgreSQL bağlantısı `DATABASE_URL` ortam değişkeni ile yapılandırılır
- Oturum Yönetimi: Express-session ve connect-pg-simple kullanılır
- Frontend routing: Wouter ile client-side routing yapılır
- Form validasyonu: React Hook Form ve Zod ile yapılır
