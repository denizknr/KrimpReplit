import { z } from "zod";
import { crimpData } from "./schema";

export const api = {
  crimpData: {
    list: {
      method: "GET" as const,
      path: "/api/crimp-data" as const,
      input: z.object({
        kontakNo: z.string().optional(),
        kesit: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof crimpData.$inferSelect>()),
      },
    },
    uniqueKontak: {
      method: "GET" as const,
      path: "/api/crimp-data/kontaklar" as const,
      responses: {
        200: z.array(z.string()),
      },
    },
    uniqueKesit: {
      method: "GET" as const,
      path: "/api/crimp-data/kesitler" as const,
      input: z.object({
        kontakNo: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.string()),
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
