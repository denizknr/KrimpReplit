import { pgTable, text, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const crimpData = pgTable("crimp_data", {
  id: serial("id").primaryKey(),
  kontakNo: text("kontak_no").notNull(),
  kalipNo: text("kalip_no").notNull(),
  krimpYuksekligi: text("krimp_yuksekligi").notNull(),
  cekmeKuvveti: text("cekme_kuvveti").notNull(),
  kesit: text("kesit").notNull(),
  krimpGenisligi: text("krimp_genisligi"),
  izokrimpYuksekligi: text("izokrimp_yuksekligi"),
});

export const insertCrimpDataSchema = createInsertSchema(crimpData).omit({ id: true });

export type CrimpData = typeof crimpData.$inferSelect;
export type InsertCrimpData = z.infer<typeof insertCrimpDataSchema>;
