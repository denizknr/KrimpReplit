# Krimp Sorgulama Projesine Katkı - Replit Kılavuzu

Bu dokümanda Replit ortamında projeye nasıl katkı vereceğiniz açıklanmaktadır.

## Replit'te Proje Açma

1. **Replit Web Sitesine Gidin**: https://replit.com
2. **Depoyu İçeri Aktar**:
   - "Create" butonuna tıklayın
   - "Import from GitHub" seçeneğini seçin
   - GitHub deposunun URL'sini girin: `https://github.com/yourusername/krimp-yuksekligi-sorgulama`
   - Replit projeyi otomatik olarak klonlayacak

## Replit'te Çalışmaya Başlama

### 1. Ortam Değişkenlerini Ayarlayın

Sol panelden "Secrets" (🔑) sekmesine tıklayın:

```
DATABASE_URL = postgresql://username:password@host:port/database
SESSION_SECRET = your-secret-key-here
NODE_ENV = development
```

> **Not**: Replit, PostgreSQL veritabanı sağlar. Replit dashboard'unda "Database" sekmesini açarak otomatik DATABASE_URL'i alabilirsiniz.

### 2. Bağımlılıkları Yükleyin

```bash
npm install
```

Replit otomatik olarak `package.json` dosyasını algılayıp bağımlılıkları yükleyecektir.

### 3. Uygulamayı Çalıştırın

```bash
npm run dev
```

Replit otomatik olarak web preview'ı açacak ve `http://localhost:5173` adresinde uygulamanız çalışacaktır.

## Veritabanı Ayarları (Replit'te)

### Veritabanını Senkronize Etme

```bash
npm run db:push
```

Bu komut Drizzle ORM schema'nızı PostgreSQL veritabanı ile senkronize eder.

### Verileri Yükleme

Veri dosyası (`attached_assets/krimp_lookup_1772797939166.html`) varsa:

```bash
# Önce veriyi JSON'a çıkartın
node script/extract_data.js

# Sonra veritabanına yükleyin
npm run db:push
```

## Kod Değişiklikleri Yapma

### Frontend (React) Değişiklikleri

Dosyalar: `client/src/` altında

```
client/src/
├── pages/          # Sayfa bileşenleri (Home.tsx, vb.)
├── components/     # Yeniden kullanılabilir UI bileşenleri
├── hooks/         # Custom React hooks
└── lib/           # Yardımcı fonksiyonlar
```

**Örnek**: Yeni bir sayfa eklemek
1. `client/src/pages/` altında yeni dosya oluşturun
2. `client/src/App.tsx` dosyasına routing ekleyin

### Backend (Express) Değişiklikleri

Dosyalar: `server/` altında

```
server/
├── routes.ts      # API endpoint'leri
├── storage.ts     # Veri katmanı (database queries)
└── index.ts       # Sunucu ana dosyası
```

**Örnek**: Yeni API endpoint'i eklemek
1. `shared/schema.ts` dosyasında Zod şeması tanımlayın
2. `server/storage.ts` dosyasında storage method'u ekleyin
3. `server/routes.ts` dosyasında endpoint'i tanımlayın

### Veri Model Değişiklikleri

Dosya: `shared/schema.ts`

1. Drizzle ORM table'ını tanımlayın
2. Zod şeması oluşturun (insert ve select)
3. TypeScript type'larını generate edin
4. `npm run db:push` komutunu çalıştırın

## Tür Kontrolü

```bash
npm run check
```

TypeScript hatalarını kontrol eder.

## Build ve Production

### Development Build

```bash
npm run build
```

### Production'da Çalıştırma

```bash
npm start
```

## Replit Specific Özellikler

### Workflow'u Yapılandırma

Replit otomatik olarak `.replit` dosyasını kullanarak uygulamayı çalıştırır:

```bash
npm run dev
```

Gerekirse Sol panel > "Tools" > "Secrets" bölümünden ortam değişkenlerini yönetebilirsiniz.

### Veritabanı Erişimi

Replit konsolu açıp PostgreSQL veritabanına doğrudan bağlanabilirsiniz:

```bash
psql $DATABASE_URL
```

Sorgu örneği:
```sql
SELECT COUNT(*) FROM crimp_data;
```

## Değişiklikleri Test Etme

1. **Frontend değişiklikleri**: Otomatik olarak `http://localhost:5173` adresinde yenilenir
2. **Backend değişiklikleri**: Workflow otomatik olarak yeniden başlar
3. **Veritabanı değişiklikleri**: `npm run db:push` çalıştırın

## Hata Giderme

### Veritabanı Bağlantısı Sorunu

```bash
# DATABASE_URL'in doğru olduğunu kontrol edin
echo $DATABASE_URL

# PostgreSQL bağlantısını test edin
psql $DATABASE_URL -c "SELECT 1"
```

### Bağımlılık Hatası

```bash
# Node modules'ü temizleyin ve yeniden yükleyin
rm -rf node_modules
npm install
```

### Porta Erişim Sorunu

Replit otomatik olarak uygun bir port bulur. Eğer port hatası alırsanız:

```bash
npm run dev
# Replit otomatik olarak çalışan port'u gösterecektir
```

## Pull Request (PR) Gönderme

1. GitHub'da forku oluşturun
2. Feature branch'i oluşturun: `git checkout -b feature/yeni-ozellik`
3. Değişiklikleri yapın ve commit edin
4. Branch'i push edin: `git push origin feature/yeni-ozellik`
5. GitHub'da Pull Request açın

PR'de aşağıdakileri belirtin:
- Yaptığınız değişiklikleri açıklayın
- Hangi dosyaları değiştirdiğiniz
- Varsa ilgili issue numarasını

## İletişim

Sorularınız varsa:

- **GitHub Issues**: Hataları ve feature request'leri rapor edin
- **GitHub Discussions**: Genel tartışmalar ve sorular

## Lisans

Bu projeye katkı verdiğinizde, katkınız MIT Lisansı altında kabul edileceğini anlıyorsunuz.

---

**Mutlu geliştirmeyi dileriz!** 🚀
